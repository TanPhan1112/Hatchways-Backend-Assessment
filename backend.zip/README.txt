1. Languade: Javascript - Node + Express
2. - install command: npm install
   - run command: npm run dev
   - test command: npm test
   - port: 3000